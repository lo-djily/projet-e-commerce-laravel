<?php

return [
    'added' => 'The product has been added to your compare list.',
    'removed' => 'The product has been removed from your compare list.',
];
