<?php

return [
    'admin.coupons' => [
        'index' => 'coupon::permissions.index',
        'create' => 'coupon::permissions.create',
        'edit' => 'coupon::permissions.edit',
        'destroy' => 'coupon::permissions.destroy',
    ],
];
