<?php

return [
    'fixer' => 'Fixer',
    'forge' => 'Forge',
    'currency_data_feed' => 'Currency Data Feed',
];
