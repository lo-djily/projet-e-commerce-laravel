<?php

return [
    'index' => 'Index Media',
    'create' => 'Create Media',
    'edit' => 'Edit Media',
    'destroy' => 'Delete Media',
];
