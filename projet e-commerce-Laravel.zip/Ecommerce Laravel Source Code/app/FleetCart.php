<?php

namespace FleetCart;

class FleetCart
{
    /**
     * The FleetCart version.
     *
     * @var string
     */
    const VERSION = '1.1.5';
}
