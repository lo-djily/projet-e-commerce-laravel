<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Attribute\\Providers\\AttributeServiceProvider',
    1 => 'Modules\\Attribute\\Providers\\RouteServiceProvider',
    2 => 'Modules\\Attribute\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Attribute\\Providers\\AttributeServiceProvider',
    1 => 'Modules\\Attribute\\Providers\\RouteServiceProvider',
    2 => 'Modules\\Attribute\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);