<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Cart\\Providers\\CartServiceProvider',
    1 => 'Modules\\Cart\\Providers\\RouteServiceProvider',
    2 => 'Modules\\Cart\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Cart\\Providers\\CartServiceProvider',
    1 => 'Modules\\Cart\\Providers\\RouteServiceProvider',
    2 => 'Modules\\Cart\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);