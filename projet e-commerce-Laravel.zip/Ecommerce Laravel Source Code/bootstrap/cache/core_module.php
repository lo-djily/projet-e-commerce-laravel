<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Core\\Providers\\CoreServiceProvider',
    1 => 'Modules\\Core\\Providers\\ThemeServiceProvider',
    2 => 'Modules\\Core\\Providers\\AssetServiceProvider',
    3 => 'Modules\\Core\\Providers\\EventServiceProvider',
    4 => 'Modules\\Core\\Providers\\SearchEngineServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Core\\Providers\\CoreServiceProvider',
    1 => 'Modules\\Core\\Providers\\ThemeServiceProvider',
    2 => 'Modules\\Core\\Providers\\AssetServiceProvider',
    3 => 'Modules\\Core\\Providers\\EventServiceProvider',
    4 => 'Modules\\Core\\Providers\\SearchEngineServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);