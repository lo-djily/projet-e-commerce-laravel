<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Coupon\\Providers\\CouponServiceProvider',
    1 => 'Modules\\Coupon\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Coupon\\Providers\\CouponServiceProvider',
    1 => 'Modules\\Coupon\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);