<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Product\\Providers\\ProductServiceProvider',
    1 => 'Modules\\Product\\Providers\\EventServiceProvider',
    2 => 'Modules\\Product\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Product\\Providers\\ProductServiceProvider',
    1 => 'Modules\\Product\\Providers\\EventServiceProvider',
    2 => 'Modules\\Product\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);