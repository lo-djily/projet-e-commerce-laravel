<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Report\\Providers\\ReportServiceProvider',
    1 => 'Modules\\Report\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Report\\Providers\\ReportServiceProvider',
    1 => 'Modules\\Report\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);